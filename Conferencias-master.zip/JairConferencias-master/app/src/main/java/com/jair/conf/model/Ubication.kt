package com.jair.conf.model

class Ubication {
    val name = "Mi House"
    val address = "Basalto 7, El Llano, 90310 San Benito Xaltocan, Tlax."
    val latitude = 19.406639
    val longitude = -98.160028
    val phone = "+52 241 135 1034"
    val webside = "https://elcantoral.com/"
    val photo = "null"
}