package com.jair.conf.view.adapter

import com.jair.conf.model.conference


class ScheduleListener {

    open fun onConferenceClicked(Conference: conference, position: Int){

    }
}