package com.jair.conf.model

import java.util.*

class conference {
    lateinit var title: String
    lateinit var speaker: String
    lateinit var description: String
    lateinit var tag: String
    lateinit var datetime: Date
}