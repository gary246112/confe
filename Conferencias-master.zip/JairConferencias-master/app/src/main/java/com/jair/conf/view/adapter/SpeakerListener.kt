package com.jair.conf.view.adapter

import com.jair.conf.model.Speaker


open class SpeakerListener {

    fun onSpeakerClicked(speaker: Speaker, position: Int){

    }

}